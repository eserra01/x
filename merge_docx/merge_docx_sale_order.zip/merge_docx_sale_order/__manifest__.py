# -*- coding: utf-8 -*-

{
    'name': 'Report Templates Sale Order',
    'description': 'Report Templates Sale Order',
    'summary': 'Report Templates Sale Order',
    'category': 'All',
    'version': '1.0',
    'website': 'http://www.build-fish.com/',
    "license": "OPL-1",
    'author': 'BuildFish',
    'depends': [
        'merge_docx_base_sale_order',
        "sale",
        "sale_management",
    ],
    'data': [
        'data/templates.xml',
        'report.xml',
    ],
    'live_test_url': 'http://demo.odoo13.newgalax.com',
    'price': 60.00,
    'currency': 'EUR',
    'images': ['static/description/banner.png'],
    'application': True,
}
